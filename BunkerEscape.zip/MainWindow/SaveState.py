class SaveState:

    def __init__(self, door, person):
        self.door = door
        self.person = person